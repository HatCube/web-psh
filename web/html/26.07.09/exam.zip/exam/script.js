const searchbth = document.getElementById("searchBtn");
const allBtn = document.getElementById("allBtn");
const message = document.getElementById("message");
const productList = document.getElementById("productList");
const count = document.getElementById("count");

function loadProducts(){
            message.innerHTML = '<div class="message">상품 정보를 불러오는 중입니다.</div>';
            const url = "https://dummyjson.com/products?limit=30"
            fetch(url)
            .then(res => res.json())
            .then(data => {

                products = data.products;

                productList.innerHTML = 
                `<div class = "product-card">
                    <img src = "${products.thumbnail}" alt = "${products.tite}">
                    <p><strong>${data.title}</strong></p>
                    <p><strong>카테고리 : </strong>${products.category}</p>
                    <p><strong>가격 : </strong>${products.price}</p>
                    <p><strong>할인률 : </strong>${products.discountPercentage}</p>
                    <p><strong>평점 : </strong>${products.rating}</p>
                    <p><strong>재고 : </strong>${products.stock}</p>
                </div>`

                count.innerText = products.total
            })
        }

        loadProducts();

        